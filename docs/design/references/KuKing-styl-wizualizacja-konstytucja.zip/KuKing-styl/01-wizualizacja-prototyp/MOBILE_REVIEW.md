# Przegląd mobilny — 12.09.2026

## Potwierdzona przyczyna

Późniejsza globalna deklaracja .page-shell nadpisywała mobilny grid.
330 px prawej kolumny i 54 px odstępu wypierały feed z ekranu.
Globalne display:flex przywracało również mobilnie ukryty licznik.

## Wprowadzone poprawki

- Jedna kolumna jako baza; dwie dopiero od 1100 px.
- Feed i formularz publikacji mają bezpieczne szerokości; przyciski układają się pionowo.
- Mobilny nagłówek nie jest przyklejony; odstęp pod dolnym paskiem uwzględnia safe area.
- Zwiększanie tekstu obejmuje treść, pola, przepisy i komentarze.
- Preferencje wyglądu zapisują się lokalnie, z obsługą niedostępnego storage.
- Szukaj otwiera istniejący ekran; fokus i tytuł dokumentu podążają za podstroną.
- Ciemniejszy kolor przycisków i tekstowych akcentów poprawia kontrast.
- Nieznany fragment adresu bezpiecznie wraca do Start.

## Research i decyzje

W3C zaleca zachowanie treści i funkcji przy szerokości 320 CSS px bez konieczności przewijania w dwóch kierunkach:
https://www.w3.org/WAI/WCAG22/Understanding/reflow.html

Stałe nagłówki i stopki nie mogą całkowicie zasłaniać elementu z fokusem:
https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html

Wniosek projektowy: priorytetem jest usunięcie kolizji układu i przewidywalność interakcji, przed dokładaniem nowych ekranów.

## Kolejne priorytety

1. Zastąpić demonstracyjne sukcesy publikacji, eksportu danych, logowania i udostępniania rzeczywistymi operacjami albo jawnym komunikatem demonstracji.
2. Testy wizualne na Firefox Android i Chrome przy 320/390/412 px, 200% tekstu i otwartej klawiaturze.
3. Wektor logo, wersja jednobarwna, optymalizacja znaku przy 24/32/48 px.
4. Testy z użytkownikami 50+: znalezienie przepisu, zapis i powrót do niego, pierwsza publikacja, odzyskanie po błędzie.
5. Porządkowanie powtarzających się reguł CSS i pełny audyt ciemnego motywu.

## Granice weryfikacji

Test check-responsive.cjs potwierdza wybrane deklaracje kaskady przy 8 szerokościach i desktopie oraz zgodność źródeł z dist. To nie jest renderowanie przeglądarki.
Składnia JavaScript i diff sprawdzone. Brak kompatybilnego zarządzanego podglądu dla statycznego projektu: bez deklaracji pełnej zgodności WCAG ani testu na urządzeniu.
