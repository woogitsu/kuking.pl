const toast = document.querySelector('.toast');
let toastTimer;

// Only appearance preferences are stored on this device; no account data.
function saveReadingPreferences() {
  const root = document.documentElement;
  try {
    localStorage.setItem('kuking.reading.v1', JSON.stringify({
      textSize: root.dataset.textSize || '100',
      dark: root.dataset.theme === 'dark',
      contrast: root.dataset.contrast === 'high'
    }));
    document.querySelector('.settings-saved').textContent = 'Wygląd zapisany w tej przeglądarce.';
  } catch {
    document.querySelector('.settings-saved').textContent = 'Wygląd zmieniony na teraz. Przeglądarka nie pozwala zapisać ustawień.';
  }
}

try {
  const saved = JSON.parse(localStorage.getItem('kuking.reading.v1') || 'null');
  if (saved && typeof saved === 'object') {
    if (['100', '112', '125'].includes(saved.textSize)) document.documentElement.dataset.textSize = saved.textSize;
    if (saved.dark === true) document.documentElement.dataset.theme = 'dark';
    if (saved.contrast === true) document.documentElement.dataset.contrast = 'high';
    document.querySelector('[data-setting="dark"]').checked = saved.dark === true;
    document.querySelector('[data-setting="contrast"]').checked = saved.contrast === true;
    document.querySelectorAll('[data-text-size]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.textSize === (saved.textSize || '100'))));
  }
} catch { /* Storage unavailable or malformed: keep safe defaults. */ }

function showToast(message) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.hidden = false;
  toastTimer = window.setTimeout(() => { toast.hidden = true; }, 5500);
}

document.addEventListener('click', (event) => {
  const control = event.target.closest('[data-action]');
  if (!control) return;

  const action = control.dataset.action;
  if (action === 'search') {
    history.pushState(null, '', '#odkrywaj');
    showView('odkrywaj');
    document.querySelector('#search-input')?.focus();
    return;
  }
  if (['share', 'share-close', 'share-copy', 'share-whatsapp', 'share-email', 'share-facebook', 'follow', 'clear-search'].includes(action)) return;
  const messages = {
    search: 'W pełnej aplikacji otworzy się wyszukiwarka osób, dań i składników.',
    'add-photo': 'Tutaj otworzy się prosty formularz: zdjęcie, kilka słów i widoczność.',
    'add-recipe': 'Tutaj rozpocznie się trzyetapowy kreator przepisu.',
    'feed-info': 'Wpisy są ułożone chronologicznie — od najnowszych, bez ukrytego rankingu.',
    cooked: 'Formularz „Ugotowałem” pozwoli dodać zdjęcie i krótką uwagę.',
    comment: 'Tutaj otworzy się rozmowa pod wpisem.',
    'load-more': 'W pełnej aplikacji pojawi się kolejna porcja wpisów.',
    'cook-mode': 'Tryb gotowania pokaże po jednym dużym kroku i uruchomi minutnik.',
    'new-folder': 'Tutaj wpiszesz nazwę nowego folderu.',
    'edit-profile': 'Tutaj zmienisz zdjęcie, nazwę i opis profilu.',
    'add-ingredient': 'Dodano miejsce na kolejny składnik.',
    'notification-open': 'Otwieram wskazaną treść.'
    , 'wake-lock': 'Podgląd: utrzymywanie włączonego ekranu nie jest tutaj aktywne.'
    , reply: 'Odpowiedź pojawi się pod tym komentarzem.'
    , 'profile-more': 'Tutaj znajdziesz opcje zgłoszenia lub zablokowania użytkownika.'
    , 'rename-folder': 'Tutaj zmienisz nazwę folderu.'
    , 'change-password': 'Podgląd: nie wysłano wiadomości i nie zmieniono hasła.'
    , 'enable-2fa': 'Podgląd: weryfikacja dwuetapowa nie została włączona.'
    , 'export-data': 'Podgląd: nie zamówiono kopii danych. Eksport działa we właściwej aplikacji Kuking.'
    , 'delete-account': 'Przed usunięciem pokażemy osobny ekran potwierdzenia i zakres danych.'
  };

  if (action === 'save') {
    const saved = control.getAttribute('aria-pressed') === 'true';
    control.setAttribute('aria-pressed', String(!saved));
    control.innerHTML = saved
      ? '<span aria-hidden="true">▱</span> Do zeszytu'
      : '<span aria-hidden="true">✓</span> W zeszycie';
    showToast('Podgląd stanu przycisku. Nie zmieniono zeszytu na koncie.');
    return;
  }

  showToast(messages[action] || 'Ta funkcja zostanie podłączona do aplikacji Laravel.');
});

const folderLinks = [...document.querySelectorAll('.folder-row a')];
folderLinks.forEach((link, index) => {
  link.href = index === 0 ? '#folder/niedziela' : '#folder/proby';
  link.dataset.route = index === 0 ? 'folder/niedziela' : 'folder/proby';
  link.querySelector('small').textContent = index === 0 ? '1 przykładowy przepis' : 'Pusty folder przykładowy';
});

function showView(name) {
  if (name === 'folder' || name === 'folder/niedziela' || name === 'folder/proby') {
    const empty = name === 'folder/proby';
    const folder = document.querySelector('[data-view="folder"]');
    folder.querySelector('#folder-title').textContent = empty ? 'Do wypróbowania' : 'Na niedzielę';
    folder.querySelector('.folder-header p:not(.eyebrow)').textContent = empty ? 'W tym przykładowym folderze nie ma jeszcze przepisów.' : '1 przykładowy przepis. Zawartość demonstracyjna.';
    folder.querySelector('.folder-grid article:not(.folder-placeholder)').hidden = empty;
    folder.querySelector('.folder-placeholder p').textContent = 'Przejdź do przykładowych dań i wybierz inspirację. Ten podgląd nie zapisuje zawartości folderów.';
    name = 'folder';
  }
  const sectionAnchor = ['jak-dziala-kuking', 'zasady-kuking'].includes(name) ? document.getElementById(name) : null;
  if (sectionAnchor) name = 'start';
  const views = [...document.querySelectorAll('[data-view]')];
  const target = views.find(view => view.dataset.view === name) || views.find(view => view.dataset.view === 'start');
  name = target?.dataset.view;
  if (!target) return;
  document.querySelectorAll('[data-view]').forEach((view) => {
    const active = view === target;
    view.hidden = !active;
    view.classList.toggle('is-visible', active);
  });
  document.querySelectorAll('[data-route]').forEach((link) => {
    const active = link.dataset.route === name || (name === 'przepis' && link.dataset.route === 'odkrywaj');
    link.classList.toggle('is-active', active);
    if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
  });
  document.body.classList.toggle('guest-mode', ['powitanie', 'logowanie', 'rejestracja', 'onboarding'].includes(name));
  window.scrollTo({ top: 0, behavior: 'instant' });
  const heading = target.querySelector('h1');
  if (heading) {
    heading.setAttribute('tabindex', '-1');
    heading.focus({ preventScroll: true });
    document.title = heading.textContent.trim() + ' — KuKing.pl';
  }
  if (sectionAnchor) {
    sectionAnchor.scrollIntoView({ block: 'start', behavior: 'instant' });
    sectionAnchor.focus({ preventScroll: true });
  }
}

document.addEventListener('click', (event) => {
  const route = event.target.closest('[data-route]');
  if (!route) return;
  event.preventDefault();
  history.pushState(null, '', route.getAttribute('href'));
  showView(route.dataset.route);
});

window.addEventListener('popstate', () => showView(location.hash.slice(1) || 'start'));
showView(location.hash.slice(1) || 'start');

const searchResults = document.querySelector('.search-results');
const searchEmpty = document.createElement('p');
searchEmpty.className = 'search-empty';
searchEmpty.hidden = true;
searchEmpty.textContent = 'Brak dopasowań w przykładowych danych. Spróbuj: placki, ziemniaki albo Halina.';
searchResults.append(searchEmpty);
const normalizeSearch = value => value.toLocaleLowerCase('pl').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ł/g, 'l');
function filterDemoSearch(phrase, category = '') {
  const words = normalizeSearch(phrase).trim().split(/\s+/).filter(Boolean);
  let count = 0;
  searchResults.querySelectorAll('.result-list article').forEach(article => {
    const isPerson = article.classList.contains('person-result');
    const text = normalizeSearch(article.textContent + (isPerson ? '' : ' ziemniaki grzyby cebula jajka mąka śmietana obiad'));
    const matches = words.every(word => text.includes(word)) && (!category || category === 'Dla Ciebie' || (category === 'Obiad' && !isPerson));
    article.hidden = !matches;
    if (matches) count += 1;
  });
  searchResults.hidden = false;
  document.querySelector('.discover-grid').hidden = true;
  searchResults.querySelector('h2').textContent = `Dopasowania w podglądzie: ${count}`;
  searchEmpty.hidden = count > 0;
}
document.querySelector('.search-panel')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const phrase = document.querySelector('#search-input').value.trim();
  if (!phrase) { resetDemoSearch(); showToast('Wpisz nazwę dania albo składnik.'); return; }
  const selected = document.querySelector('[data-view="odkrywaj"] .filter-chips button[aria-pressed="true"]');
  filterDemoSearch(phrase, selected?.textContent.trim());
  document.querySelector('.search-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
  showToast(`Wyniki dla: „${phrase}”.`);
});

function resetDemoSearch() {
  document.querySelector('.search-results').hidden = true;
  document.querySelector('.discover-grid').hidden = false;
  document.querySelector('#search-input').value = '';
  document.querySelectorAll('[data-view="odkrywaj"] .filter-chips button').forEach((button, index) => button.setAttribute('aria-pressed', String(index === 0)));
  document.querySelector('#search-input').focus();
  searchResults.querySelectorAll('.result-list article').forEach(article => { article.hidden = false; });
  searchEmpty.hidden = true;
}
document.querySelector('[data-action="clear-search"]')?.addEventListener('click', resetDemoSearch);
document.querySelector('#search-input')?.addEventListener('input', event => {
  if (!event.target.value) resetDemoSearch();
});

document.querySelector('[data-action="follow"]')?.addEventListener('click', (event) => {
  const button = event.currentTarget;
  const active = button.getAttribute('aria-pressed') === 'true';
  button.setAttribute('aria-pressed', String(!active));
  button.textContent = active ? '＋ Obserwuj' : '✓ Obserwujesz';
  showToast('Podgląd obserwowania. Nie zmieniono listy osób na koncie.');
});

const shareDialog = document.querySelector('.share-dialog');
document.querySelector('[data-action="share"]')?.addEventListener('click', () => {
  shareDialog.querySelector('#share-address').value = new URL('#przepis', location.href).href;
  shareDialog.querySelector('[data-share-status]').textContent = '';
  shareDialog.showModal();
});
document.querySelector('[data-action="share-close"]')?.addEventListener('click', () => shareDialog.close());
shareDialog?.addEventListener('click', (event) => { if (event.target === shareDialog) shareDialog.close(); });
document.querySelectorAll('[data-action^="share-"]:not([data-action="share-close"])').forEach((button) => {
  button.addEventListener('click', async () => {
    if (button.dataset.action !== 'share-copy') {
      shareDialog.querySelector('[data-share-status]').textContent = 'Podgląd: nie wysłano wiadomości ani nie otwarto serwisu zewnętrznego.';
      return;
    }
    const field = shareDialog.querySelector('#share-address');
    field.value = new URL('#przepis', location.href).href;
    button.disabled = true;
    try {
      await navigator.clipboard.writeText(field.value);
      shareDialog.querySelector('[data-share-status]').textContent = 'Skopiowano adres podglądu. Dostęp zależy od uprawnień do tej strony.';
    } catch {
      shareDialog.querySelector('[data-share-status]').textContent = 'Nie udało się skopiować automatycznie. Zaznaczony adres możesz skopiować ręcznie.';
      field.focus();
      field.select();
    } finally { button.disabled = false; }
  });
});

document.querySelectorAll('[data-account-tab]').forEach((button) => {
  button.addEventListener('click', () => {
    const name = button.dataset.accountTab;
    document.querySelectorAll('[data-account-tab]').forEach((item) => item.classList.toggle('is-active', item === button));
    document.querySelectorAll('[data-account-panel]').forEach((panel) => { panel.hidden = panel.dataset.accountPanel !== name; });
  });
});

document.querySelectorAll('.filter-chips button').forEach((button) => {
  button.addEventListener('click', () => {
    button.closest('.filter-chips').querySelectorAll('button').forEach((item) => item.setAttribute('aria-pressed', 'false'));
    button.setAttribute('aria-pressed', 'true');
    if (button.closest('[data-view="odkrywaj"]')) {
      filterDemoSearch(document.querySelector('#search-input').value, button.textContent.trim());
      return;
    }
    showToast(`Wybrano: ${button.textContent}.`);
  });
});

document.querySelector('[data-form="post"]')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const text = document.querySelector('#post-text').value.trim();
  if (!text) {
    showToast('Napisz kilka słów o daniu, żeby opublikować wpis.');
    document.querySelector('#post-text').focus();
    return;
  }
  showToast('Podgląd: wpis nie został opublikowany. Tekst pozostaje w formularzu do zamknięcia lub odświeżenia strony.');
});

const wizard = document.querySelector('.recipe-wizard');
let wizardStep = 1;
function updateWizard(moveFocus = false) {
  wizard?.querySelectorAll('.wizard-step').forEach((step) => {
    const active = Number(step.dataset.step) === wizardStep;
    step.hidden = !active;
    step.classList.toggle('is-active', active);
  });
  const names = ['O przepisie', 'Składniki', 'Przygotowanie'];
  wizard.querySelector('[data-step-number]').textContent = wizardStep;
  wizard.querySelector('[data-step-name]').textContent = names[wizardStep - 1];
  wizard.querySelectorAll('.wizard-progress i').forEach((bar, index) => {
    bar.classList.toggle('is-active', index + 1 === wizardStep);
    bar.classList.toggle('is-complete', index + 1 < wizardStep);
  });
  const previous = wizard.querySelector('[data-wizard="prev"]');
  const next = wizard.querySelector('[data-wizard="next"]');
  previous.disabled = wizardStep === 1;
  next.textContent = wizardStep === 3 ? 'Zakończ podgląd przepisu' : 'Dalej';
  if (moveFocus) wizard.querySelector('.wizard-step:not([hidden]) input, .wizard-step:not([hidden]) textarea')?.focus();
}
wizard?.addEventListener('click', (event) => {
  const control = event.target.closest('[data-wizard]');
  if (!control) return;
  if (control.dataset.wizard === 'prev') wizardStep = Math.max(1, wizardStep - 1);
  if (control.dataset.wizard === 'next' && wizardStep < 3) wizardStep += 1;
  else if (control.dataset.wizard === 'next' && wizardStep === 3) {
    showToast('Podgląd: przepis nie został opublikowany. Wpisane dane pozostają tutaj do odświeżenia lub zamknięcia strony.');
    return;
  }
  updateWizard(true);
});
updateWizard();
wizard?.addEventListener('submit', event => {
  event.preventDefault();
  showToast('To podgląd formularza. Przepis nie jest wysyłany ani zapisywany.');
});

document.querySelector('.upload-zone')?.addEventListener('click', () => showToast('Tutaj otworzy się wybór zdjęcia z urządzenia.'));
document.querySelector('.upload-zone')?.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    showToast('Tutaj otworzy się wybór zdjęcia z urządzenia.');
  }
});

const cookSteps = [
  ['Przygotuj ziemniaki', 'Zetrzyj ziemniaki i cebulę na drobnych oczkach. Przełóż na sito i dokładnie odciśnij nadmiar wody.', 'Im mniej wody zostanie w ziemniakach, tym bardziej chrupiące będą placki.'],
  ['Wymieszaj ciasto', 'Dodaj jajka, mąkę, sól i odrobinę majeranku. Wymieszaj tylko do połączenia składników.', 'Nie dosypuj zbyt dużo mąki — placki zrobią się ciężkie.'],
  ['Usmaż placki', 'Nakładaj niewielkie porcje na dobrze rozgrzany olej. Smaż z obu stron na mocno złoty kolor.', 'Gotowe placki odkładaj na papier, żeby pozbyć się nadmiaru tłuszczu.'],
  ['Zrób sos', 'Podsmaż grzyby z cebulą, dodaj śmietanę i duś około 10 minut. Dopraw solą i pieprzem.', 'Sos powinien lekko zgęstnieć, ale nadal łatwo spływać z łyżki.']
];
let cookStep = 0;
function updateCookStep() {
  document.querySelector('[data-cook-current]').textContent = cookStep + 1;
  document.querySelector('[data-cook-title]').textContent = cookSteps[cookStep][0];
  document.querySelector('[data-cook-instruction]').textContent = cookSteps[cookStep][1];
  document.querySelector('[data-cook-tip] p').textContent = cookSteps[cookStep][2];
  const prev = document.querySelector('[data-cook="prev"]');
  const next = document.querySelector('[data-cook="next"]');
  prev.disabled = cookStep === 0;
  next.textContent = cookStep === cookSteps.length - 1 ? 'Gotowe — pokaż efekt' : 'Gotowe, następny krok →';
  document.querySelectorAll('.cook-progress i').forEach((bar, index) => {
    bar.classList.toggle('is-active', index === cookStep);
    bar.classList.toggle('is-complete', index < cookStep);
  });
}
document.querySelector('.cooking-view')?.addEventListener('click', (event) => {
  const control = event.target.closest('[data-cook]');
  if (!control) return;
  if (control.dataset.cook === 'prev') cookStep = Math.max(0, cookStep - 1);
  if (control.dataset.cook === 'next' && cookStep < cookSteps.length - 1) cookStep += 1;
  else if (control.dataset.cook === 'next' && cookStep === cookSteps.length - 1) {
    showToast('Świetnie! Teraz możesz dodać zdjęcie i oznaczyć „Ugotowałem”.');
    history.pushState(null, '', '#przepis');
    showView('przepis');
  }
  updateCookStep();
});
updateCookStep();

document.querySelector('.comment-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const field = document.querySelector('#comment-text');
  if (!field.value.trim()) { showToast('Napisz komentarz przed wysłaniem.'); field.focus(); return; }
  showToast('Podgląd: komentarz nie został wysłany. Tekst pozostaje w polu do odświeżenia lub zamknięcia strony.');
});

document.querySelectorAll('[data-text-size]').forEach((button) => {
  button.addEventListener('click', () => {
    document.documentElement.dataset.textSize = button.dataset.textSize;
    document.querySelectorAll('[data-text-size]').forEach((item) => item.setAttribute('aria-pressed', String(item === button)));
    saveReadingPreferences();
    showToast('Wielkość tekstu została zmieniona.');
  });
});
document.querySelector('[data-setting="dark"]')?.addEventListener('change', (event) => {
  if (event.target.checked) document.documentElement.dataset.theme = 'dark'; else delete document.documentElement.dataset.theme;
  saveReadingPreferences();
  showToast(event.target.checked ? 'Włączono ciemny wygląd.' : 'Włączono jasny wygląd.');
});
document.querySelector('[data-setting="contrast"]')?.addEventListener('change', (event) => {
  if (event.target.checked) document.documentElement.dataset.contrast = 'high'; else delete document.documentElement.dataset.contrast;
  saveReadingPreferences();
  showToast(event.target.checked ? 'Włączono mocniejszy kontrast.' : 'Przywrócono zwykły kontrast.');
});

document.querySelectorAll('[data-auth]').forEach((form) => {
  const notice = document.createElement('p');
  notice.className = 'demo-note';
  notice.textContent = 'To podgląd, nie prawdziwe logowanie. Pola są wyłączone — nie podawaj hasła. Przycisk pokaże następny ekran bez tworzenia konta.';
  form.querySelector('h1').after(notice);
  form.querySelectorAll('input').forEach(input => { input.disabled = true; });
  form.querySelector('[type="submit"]').textContent = 'Przejdź dalej w podglądzie';
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const destination = form.dataset.auth === 'register' ? 'onboarding' : 'start';
    showToast('Otwierasz przykładowy ekran. Nie zalogowano ani nie utworzono konta.');
    history.pushState(null, '', `#${destination}`);
    showView(destination);
  });
});

document.querySelectorAll('.interest-grid button').forEach((button) => {
  button.addEventListener('click', () => {
    const selected = button.getAttribute('aria-pressed') === 'true';
    button.setAttribute('aria-pressed', String(!selected));
  });
});
document.querySelector('[data-onboarding="next"]')?.addEventListener('click', () => {
  const selected = document.querySelectorAll('.interest-grid button[aria-pressed="true"]').length;
  if (!selected) { showToast('Wybierz przynajmniej jeden temat albo kliknij „Na razie tylko pooglądam”.'); return; }
  showToast('Wybrano tematy w podglądzie. Przykładowe wpisy pozostają bez zmian.');
  history.pushState(null, '', '#start');
  showView('start');
});
document.querySelector('[data-onboarding="skip"]')?.addEventListener('click', () => {
  history.pushState(null, '', '#start');
  showView('start');
});

document.querySelectorAll('.people-list button').forEach((button) => {
  button.addEventListener('click', () => {
    const following = button.getAttribute('aria-pressed') === 'true';
    button.setAttribute('aria-pressed', String(!following));
    button.textContent = following ? 'Obserwuj' : 'Obserwujesz';
    showToast('Podgląd obserwowania. Nie zmieniono listy osób na koncie.');
  });
});
