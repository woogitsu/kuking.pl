# KuKing.pl — wizualizacja i identyfikacja marki

## Zawartość
- **01-wizualizacja-prototyp** — oryginalna interaktywna wizualizacja HTML/CSS/JS, obrazy, koncepcja logo i pierwotna konstytucja v1.0. Otwórz index.html w przeglądarce. Jeśli przeglądarka ogranicza działanie lokalnych plików, uruchom w tym katalogu `python3 -m http.server 8000` i otwórz http://localhost:8000.
- **02-marka-w-repo** — konstytucja, COPY_STYLE, GLOS_MARKI, tokeny i główne arkusze marki oraz znak SVG z repozytorium, commit dbd1cb920f872233f8cc8f240f94273f26f634e8 (Alfa 0.11, PR #494).
- **03-zrzuty-portu** — dostępne zrzuty wcześniejszego portu Alfa 0.9: strona główna na telefonie i komputerze, wyszukiwanie oraz profil. To historyczne obrazy weryfikacyjne, nie potwierdzenie aktualnego wyglądu produkcji.

## Ważne rozróżnienie
Wizualizacja jest zachowaną oryginalną makietą z przykładowymi danymi i symulowanymi funkcjami. Ma jeszcze tymczasowy znak K i pierwotne teksty. Nie jest produkcyjną aplikacją ani aktualnym źródłem zasad marki. Nowsze zasady i właściwy znak garnka znajdują się w 02-marka-w-repo. Plik logo-concept-v2.png to koncepcja, nie zamiennik kanonicznego SVG.

Arkusze w katalogu 02 są materiałem źródłowym dla aplikacji Laravel i nie stanowią samodzielnego kompletnego buildu. Pełna aplikacja: https://github.com/woogitsu/kuking.pl.

Paczka nie zawiera bazy danych, sekretów ani plików konfiguracyjnych środowiska. Nie potwierdza zakończenia wdrożenia Railway.
